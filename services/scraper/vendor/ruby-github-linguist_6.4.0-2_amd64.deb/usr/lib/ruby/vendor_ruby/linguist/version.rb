module Linguist
  VERSION = "6.4.0"
end
